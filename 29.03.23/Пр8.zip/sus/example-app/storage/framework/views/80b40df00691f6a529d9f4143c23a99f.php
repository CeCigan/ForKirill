<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        td{
            border: 1px solid black;
        }
    </style>
    <title>Document</title>
</head>
<body>
    <section class="content">
        <table>
            <tr>
                <td>Id</td>
                <td>Описание</td>
                <td>Теги</td>
                <td>Текст</td>
                <td>Дата</td>
                <td style = 'display:none;'></td>
            </tr>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $id = $post->id;
            ?>
                <tr>
                    <td style = 'padding: 0 20px 0 20px;'><?php echo e($post->id); ?></td>
                    <td><a href = './get/<?php echo e($post->id); ?>'><?php echo e($post->title); ?></a></td>
                    <td><?php echo e($post->description); ?></td>
                    <td><?php echo e($post->text); ?></td>
                    <td><?php echo e($post->date); ?></td>
                    <?php if(isset($message)): ?>
                        <td><a href="/sus/example-app/public/posts/getdelposts/restore/<?php echo e($post->id); ?>">Восстановить</a></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table><br>

        <?php if(!isset($message)): ?>
            <a href="http://pr9/sus/example-app/public/posts/new">Создать новый пост</a><br>
            <a href="getdelposts">Удаленные посты</a><br>
        <?php endif; ?>

        <?php if(isset($message)): ?>
            <a href = "http://pr9/sus/example-app/public/posts/all">Вернуться на главную</a><br>
        <?php endif; ?>

        <?php
            return view('flash_message')
        ?>
    </section>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\pr9\sus\example-app\resources\views/info.blade.php ENDPATH**/ ?>