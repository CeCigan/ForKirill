<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="create" method = 'POST'>
        <?php echo csrf_field(); ?>
        <label for="title">Описание</label><br>
        <input type="text" name="title" id=""><br><br>

        <label for="title">Теги</label><br>
        <input type="text" name="description" id=""><br><br>

        <label for="title">Текст</label><br>
        <textarea name="text" id="" cols="30" rows="10"></textarea><br><br>

        <label for="title">Дата</label><br>
        <input type="date" name="date" id=""><br><br>
        <input type="submit" value="Принять">
    </form>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\pr9\sus\example-app\resources\views/form.blade.php ENDPATH**/ ?>