<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        td{
            border: 1px solid black;
        }
    </style>
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <td>Id</td>
            <td>Описание</td>
            <td>Текст</td>
            <td>Дата</td>
        </tr>
        <tr>
            <td><?php echo e($id); ?></td>
            <td><?php echo e($title); ?></td>
            <td><?php echo e($description); ?></td>
            <td><?php echo e($text); ?></td>
            <td><?php echo e($date); ?></td>
        </tr>
    </table>
    <a href="http://pr9/sus/example-app/public/posts/update/<?php echo e($id); ?>">Отредактировать пост</a>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\pr9\sus\example-app\resources\views/post.blade.php ENDPATH**/ ?>