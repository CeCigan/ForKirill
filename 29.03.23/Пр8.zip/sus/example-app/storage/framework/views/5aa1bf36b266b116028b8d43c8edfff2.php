<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        td{
            border: 1px solid black;
        }
    </style>
    <title>Document</title>
</head>
<body>
    <section class="content">
        <table>
            <tr>
                <td>Id</td>
                <td>Описание</td>
                <td>Текст</td>
                <td>Дата</td>
            </tr>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $id = $post->id;
            ?>
                <tr>
                    <td style = 'padding: 0 20px 0 20px;'><?php echo e($post->id); ?></td>
                    <td><a href = './get/<?php echo e($post->id); ?>'><?php echo e($post->description); ?></a></td>
                    <td><?php echo e($post->text); ?></td>
                    <td><?php echo e($post->date); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </section>
</body>
</html><?php /**PATH C:\OSPanel\domains\makeevsky\laravel\example-app\resources\views/info.blade.php ENDPATH**/ ?>