<?php if(Session::has('succes')): ?>
    <div class="alert alert-succes">
        <?php echo e(Session::has('succes')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\OSPanel\domains\pr9\sus\example-app\resources\views/flash_message.blade.php ENDPATH**/ ?>