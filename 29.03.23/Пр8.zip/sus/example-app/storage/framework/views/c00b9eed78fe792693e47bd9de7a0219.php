
<?php $__env->startSection('title-block'); ?>Страница контактов@endsectic
<?php $__env->startSection('content'); ?>

<h1>Страница контактов</h1>
<form action="/form/square" method="post">
    <div class="form-group">
        <label for="number">Введите число</label>
        <input type="text" name="number" id="" placeholder="Введите число">
    </div>
    <button type="submit" class = 'btn btn-succes'>Выполнить</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\makeevsky\laravel\example-app\resources\views/form.blade.php ENDPATH**/ ?>