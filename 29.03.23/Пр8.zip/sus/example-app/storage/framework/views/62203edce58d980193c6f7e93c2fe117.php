<?php if(session('succes')): ?>
    <div class="succes">
        <?php echo e(Session::get('succes')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\OSPanel\domains\pr9\sus\example-app\resources\views/flash-message.blade.php ENDPATH**/ ?>