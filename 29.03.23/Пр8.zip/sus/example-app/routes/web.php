<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\PostController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/five', [MainController::class, 'showMass']);

Route::get('/employees', [MainController::class, 'showEmployees']);

Route::get('/rows/{row}', [MainController::class, 'showRows']);

Route::get('/nums/{arrNums}/{title}/{aside}', [MainController::class, 'showArrNums']);

Route::get('/users', [MainController::class, 'showUsers']);

Route::get('/date/{days}/{day}', [MainController::class, 'showDays']);

Route::get('/dbusers', [MainController::class, 'showDbUsers']);

Route::get('/posts/all/', [PostController::class, 'getAllPosts']);

Route::get('/posts/get/{id}', [PostController::class, 'getOnePost']);

Route::get('/posts/new', [PostController::class, 'addPost']);

Route::post('/posts/create', [PostController::class, 'result']);

Route::post('/posts/update/{id}', [PostController::class, 'update']);

Route::match(['get', 'post'], '/posts/update1Post', [PostController::class, 'updatePost']);

Route::get('/posts/getdelposts', [PostController::class, 'getDelPosts']);

Route::match(['get', 'post'], '/posts/delete/{id}', [PostController::class, 'delete']);

Route::match(['get', 'post'], '/posts/plushDelete/{{$id}}', [PostController::class, 'plushDelete']);

Route::match(['get', 'post'], '/posts/getdelposts/restore/{id}', [PostController::class, 'restorePost']);





