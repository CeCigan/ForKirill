<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        td{
            border: 1px solid black;
        }
    </style>
    <title>Document</title>
</head>
<body>
    <section class="content">
        <table>
            <tr>
                <td>Id</td>
                <td>Описание</td>
                <td>Теги</td>
                <td>Текст</td>
                <td>Дата</td>
            </tr>
            @foreach ($posts as $post)
            @php
                $id = $post->id;
            @endphp
                <tr>
                    <td style = 'padding: 0 20px 0 20px;'>{{$post->id}}</td>
                    <td><a href = './get/{{$post->id}}'>{{$post->title}}</a></td>
                    <td>{{$post->description}}</td>
                    <td>{{$post->text}}</td>
                    <td>{{$post->date}}</td>
                </tr>
            @endforeach
        </table><br>
        <a href="http://pr9/sus/example-app/public/posts/new">Создать новый пост</a>
    </section>
</body>
</html>
