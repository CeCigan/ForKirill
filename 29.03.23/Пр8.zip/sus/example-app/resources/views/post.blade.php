<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        td{
            border: 1px solid black;
        }
    </style>
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <td>Id</td>
            <td>Описание</td>
            <td>Теги</td>
            <td>Текст</td>
            <td>Дата</td>
        </tr>
        <tr>
            <td>{{$id}}</td>
            <td>{{$title}}</td>
            <td>{{$description}}</td>
            <td>{{$text}}</td>
            <td>{{$date}}</td>
        </tr>
    </table>
    <a href="http://pr9/sus/example-app/public/posts/update/{{$id}}">Отредактировать пост</a>
</body>
</html>
