<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <footer style = 'color:rgb(231, 175, 102);'>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Assumenda, provident iusto praesentium amet voluptatibus consectetur doloremque doloribus molestiae odio? Iure, quod enim? Doloribus nam, alias aspernatur numquam eum facere nobis?
        Accusamus odit quo suscipit dolor nihil omnis, maxime recusandae facilis ratione hic porro officia eaque ducimus ea laudantium dicta dolorum quod eligendi voluptates aut earum corporis animi tempora beatae. Eaque?
    </footer>
</body>
</html>