<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header style = 'color:rgb(37, 37, 223);'>
        Impedit quibusdam obcaecati ex quis tenetur mollitia necessitatibus voluptatum corrupti hic sunt porro id, quia numquam, distinctio accusantium quidem. Nemo labore voluptatibus voluptate possimus iste sed unde necessitatibus iusto? Ipsam?
        Et ut aliquam, culpa excepturi modi neque illo sint consectetur doloremque iste cupiditate ex veritatis perspiciatis commodi tenetur ipsum saepe, nulla optio error quis. Accusantium esse autem maiores et vel?
    </header><br>
</body>
</html>