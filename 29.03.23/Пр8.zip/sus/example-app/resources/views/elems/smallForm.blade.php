<form action="">
    @scrf
    <input type="text" name="title" id="">
    <input type="text" name="description" id="">
</form>
