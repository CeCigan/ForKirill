<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Posts;
use Ramsey\Uuid\Type\Integer;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Redirect;
use PhpParser\Node\Stmt\Return_;

function setData(){
    $title = $_POST['title'];
    $description = $_POST['description'];
    $text = $_POST['text'];
    $date = $_POST['date'];

    $post = new Posts;
    $post->title = $title;
    $post->description = $description;
    $post->text = $text;
    $post->date = $date;

    $post->save();
    echo 'Created';
}

class PostController extends Controller
{
    public function getAllPosts($order = 'date')
    {
        if($order == 'text'){
            $posts = Posts::orderBy('date')->get();
        } else {
            $posts = Posts::orderBy($order)->get();
        }

        return view('info') ->with(['posts' => $posts]);
    }

    public function getOnePost($id)
    {
        if(!Posts::find((int)$id)){
            return view('404');
        }

        $post = Posts::find((int) $id);
        $id = $post->id;
        $title = $post->title;
        $description = $post->description;
        $text = $post->text;
        $date = $post->date;
        return view('post') ->with([
            'id' => $id,
            'description' => $description,
            'text' => $text,
            'date' => $date,
            'title' => $title
        ]);
    }

    public function addPost(){
        return view('form');
    }

    public function result()
    {
        setData();
        echo '<a href = "http://pr9/sus/example-app/public/posts/all">Все посты</a>';
    }

    public function update($id)
    {
        return view('form');
    }

    public function delete($id)
    {
        $title = Posts::where('id', '=', (int)$id)->value('title');
        Posts::where('id', '=', (int)$id)->delete();

        return Redirect::to('/posts/all')->withSuccess('success', 'Запись: ' . $id . ' название: ' . $title . 'удалена');
    }
}
