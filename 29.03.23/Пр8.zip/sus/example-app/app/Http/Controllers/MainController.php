<?php
namespace App\Http\Controllers;

use Illuminate\Support\Arr;
use PhpParser\Node\Expr\FuncCall;
use PHPUnit\Framework\Constraint\SameSize;
use Illuminate\Support\Facades\DB;


class MainController extends Controller{
    public function showMass()
    {
        $arr = [
            [1, 2, 3, 4, 5],
            [6, 7, 8, 9, 10],
            [11, 12, 13, 14, 15],
            [16, 17, 18, 19, 20],
            [21, 22, 23, 24, 25],
        ];

       return view('info') -> with(['fives' => $arr]);
    }

    public function showEmployees(){
        $employees = [
            [
                'name' => 'user1',
                'surname' => 'surname1',
                'salary' => 1000,
            ],
            [
                'name' => 'user2',
                'surname' => 'surname2',
                'salary' => 2000,
            ],
            [
                'name' => 'user3',
                'surname' => 'surname3',
                'salary' => 3000,
            ],
        ];
        
        return view('info') -> with(['employees' => $employees]);
    }

    public function showRows($row){
        $arr = explode(',', $row);

        return view('info') -> with(['row' => $arr ]);
    }

    public function showArrNums($nums, $title, $aside){
        $sepNums = explode(',', $nums);

        return view('info') -> with([
        'nums' => $sepNums,
        'title' => $title, 
        'aside' => $aside, 
        ]);
    }

    public function showUsers(){
        $links = [
            [
                'name' => 'user1',
                'surname' => 'surname1',
                'banned' => true,
            ],
            [
                'name' => 'user2',
                'surname' => 'surname2',
                'banned' => false,
            ],
            [
                'name' => 'user3',
                'surname' => 'surname3',
                'banned' => true,
            ],
            [
                'name' => 'user4',
                'surname' => 'surname4',
                'banned' => false,
            ],
            [
                'name' => 'user5',
                'surname' => 'surname5',
                'banned' => false,
            ],
        ];

        return view('info') ->with(['links' => $links]);
    }

    public function showDays($days, $day)
    {
        $mas = [];
        for($i = 1; $i <= $days; $i++){
            $mas[$i] = $i;
        }

        return view('info')->with(['mas'=>$mas, 'day' => $day]);
    }

    public function showDbUsers()
    {
        $data = DB::table('users')->where('age', '<', 18)->get();
        dump($data);

        return view('info')->with(['data' => $data]);
    }

    public function findSquare()
    {
        return view('form');
    }
}