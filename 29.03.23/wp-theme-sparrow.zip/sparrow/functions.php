<?php
add_action('wp_enqueue_scripts','style_theme');
add_action('wp_footer','scripts_theme');
add_action('wp_enqueue_script','scripts_head_theme');
add_action('after_setup_theme','theme_register_nav_menu');
add_action('widgets_init','register_my_widgets');

function register_my_widgets(){
    register_sidebar(array(
        'name'          => 'Left Sidebar',
        'id'            => 'left_sidebar',
        'description'   => 'Опиание нашего сайдбара',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="widgettitle">',
        'after_title'   => '</h5>',
    ) );
    register_sidebar(array(
        'name'          => 'Top Sidebar',
        'id'            => 'top_sidebar',
        'description'   => 'Верхний сайдбар',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="widgettitle">',
        'after_title'   => '</h5>',
    ) );
}

function theme_register_nav_menu()
{
    register_nav_menu('top', 'Меню в шапке');
    register_nav_menu('footer', 'Меню в подвале');
}

function style_theme(){
    wp_enqueue_style('style',get_stylesheet_uri()); // подключает главный файл стилей
// подключаем все остальные файлы стилей
    wp_enqueue_style('default',get_template_directory_uri().'/assets/css/default.css'   );
    wp_enqueue_style('layout',get_template_directory_uri().'/assets/css/layout.css'   );
    wp_enqueue_style('media',get_template_directory_uri().'/assets/css/media-queries.css'   );
}

function scripts_head_theme(){
    wp_enqueue_script('modernizr',get_template_directory_uri().'/assets/js/modernizr.js'   );
}
function scripts_theme(){
    //wp_deregister_script('jquery');
    //wp_register_script('jquery','//ajax.googleapis.com/ajax/libs/jquery/1.10.2/');
    wp_enqueue_script('doubletaptogo',get_template_directory_uri().'/assets/js/doubletaptogo.js'   );
    wp_enqueue_script('flexslider',get_template_directory_uri().'/assets/js/jquery.flexslider.js'   );
    wp_enqueue_script('migrate',get_template_directory_uri().'/assets/js/jquery-migrate-1.2.1.min.js'   );
    wp_enqueue_script('jquery',get_template_directory_uri().'/assets/js/jquery.jquery-1.10.2.min.js');
    wp_enqueue_script('init',get_template_directory_uri().'/assets/js/init.js'   );
}

?>