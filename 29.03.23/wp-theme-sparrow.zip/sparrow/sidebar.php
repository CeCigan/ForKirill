<aside id="sidebar">
    <?php dynamic_sidebar('left_sidebar'); ?>
</aside>