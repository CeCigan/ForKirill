<?php
add_action('wp_enqueue_scripts', 'style_theme');
add_action('wp_footer', 'scripts_theme');
add_action('wp_enqueue_script', 'scripts_head_theme');
add_action('after_setup_theme', 'theme_register_nav_menu');
add_action('widgets_init', 'register_my_widgets');

add_filter('the_content', 'test_content');

function test_content($content)
{
    return $content . 'Читать далее...';
}

function register_my_widgets()
{
    register_sidebar(array(
        'name' => 'Left Sidebar',
        'id' => "left_sidebar",
        'description' => 'Описание нашего сайдбара',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => "</div>\n",
        'before_title' => '<h5 class="widgettitle">',
        'after_title' => "</h5>\n",
    ));
    register_sidebar(array(
        'name' => 'Top Sidebar',
        'id' => "top_sidebar",
        'description' => 'Верхний сайдбар',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => "</div>\n",
        'before_title' => '<h5 class="widgettitle">',
        'after_title' => "</h5>\n",
    ));
    register_sidebar(array(
        'name' => 'Bottom Sidebar',
        'id' => "bottom_sidebar",
        'description' => 'Нижний сайдбар',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => "</div    >\n",
        'before_title' => '<h5 class="widgettitle">',
        'after_title' => "</h5>\n",
    ));
}

function theme_register_nav_menu()
{
    register_nav_menu('top', 'Меню в шапке');
    register_nav_menu('bottom', 'Меню в подвале');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails', array('post'));
    add_theme_support('post-formats', array('video', 'aside', 'chat', 'gallery'));
    add_image_size('post_thumb', 1300, 500, true);
    add_filter('excerpt_more', 'new_excerpt_more');
    function new_excerpt_more($more)
    {
        global $post;
        return '<a href="' . get_permalink($post->ID) . '"> Читать далее...</a>';
    }
}

function style_theme()
{
    wp_enqueue_style('style', get_stylesheet_uri()); // подключает главный файл стилей
    // подключаем все остальные файлы стилей
    wp_enqueue_style('default', get_template_directory_uri() . './assets/css/default.css');
    wp_enqueue_style('layout', get_template_directory_uri() . './assets/css/layout.css', false, time());
    wp_enqueue_style('media', get_template_directory_uri() . './assets/css/media-queries.css');
}

function scripts_head_theme()
{
    wp_enqueue_script('modernizr', get_template_directory_uri() . './assets/js/modernizr.js');
}
function scripts_theme()
{
    wp_enqueue_script('doubletaptogo', get_template_directory_uri() . './assets/js/doubletaptogo.js');
    wp_enqueue_script('flexslider', get_template_directory_uri() . './assets/js/jquery.flexslider.js');
    wp_enqueue_script('migrate', get_template_directory_uri() . './assets/js/jquery-migrate-1.2.1.min.js');
    wp_enqueue_script('jquery', get_template_directory_uri() . './assets/js/jquery.jquery-1.10.2.min.js');
    wp_enqueue_script('init', get_template_directory_uri() . './assets/js/init.js');
}


add_shortcode('my_short', 'short_function');

function short_function()
{
    return "Я шорткод!";
}
