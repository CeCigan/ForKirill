<aside id="sidebar">

    <?php dynamic_sidebar('bottom_sidebar') ?>

</aside>