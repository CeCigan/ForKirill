<?php get_header(); ?>

<!-- Page Title
   ================================================== -->
<?php echo get_post_format() ?>

<!-- Content
   ================================================== -->
<div class="content-outer">

   <div id="page-content" class="row">

      <div id="primary" class="eight columns">

         <?php get_template_part('post-templates/post', get_post_format()); ?>

      </div>
      </section> <!-- Tweet Section End-->

      <?php get_footer(); ?>