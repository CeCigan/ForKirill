<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Trip;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Cookie;

class UserController extends Controller
{
    public function loginPage(){
        return view('login');
    }
    public function loginUser(Request $request){
        $login = $request->input('login');
        $password = $request->input('password');

        if($authUser = User::where([
            'login'=>$login,
            'password'=>$password
        ])->first()){
            $authUser->token = Str::random(60);
            $authUser->save();
            Cookie::queue('token',$authUser->token, 60);
            return redirect('/console');
        };
        return "Попробуйле войти еще раз!";
    }



    public function registerPage(){
        return view('register');
    }
    public function registerUser(Request $request){
        $login = $request->input('login');
        $password = $request->input('password');
        $name = $request->input('name');

        if($createUser = User::create([
            'login'=>$login,
            'password'=>$password,
            'name'=>$name,
            'role_id'=>0
        ])){
            return redirect('/auth');
        }
        return "Попробуйте зарегистрироваться еще раз!";
    }


    public function logoutUser(Request $request){
        $user = User::where('token', $request->cookie('token'))->first();
        Cookie::forget('token');
        $user->token = null;
        $user->save();
        return redirect('/auth');
    }


    public function cart(Request $request){
        $token = $request->cookie('token');
        if($token == null){
            return redirect('/auth');
        }
        if(!$user = User::where('token',$token)->first()){
            return redirect('/auth');
        }

        $trips = $user->trips;
        return view('cart',['trips'=>$trips]);
    }

    public function cartDelete($id, Request $request){
        $token = $request->cookie('token');
        if($token == null){
            return redirect('/auth');
        }
        if(!$user = User::where('token',$token)->first()){
            return redirect('/auth');
        }

        $trip = Trip::where('id', $id)->first();

        $user->trips()->detach($trip);
        return redirect('/cart');
    }

    public function cartAdd(Request $request, $id){
        $token = $request->cookie('token');
        if($token == null){
            return redirect('/auth');
        }
        if(!$user = User::where('token',$token)->first()){
            return redirect('/auth');
        }

        $trip = Trip::where('id', $id)->first(); 
        $user->trips()->attach($trip);
        return redirect('/');
    }
}
