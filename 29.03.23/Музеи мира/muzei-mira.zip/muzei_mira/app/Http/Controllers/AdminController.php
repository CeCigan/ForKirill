<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;

class AdminController extends Controller
{
    public function acConsole(Request $request){
        $token = $request->cookie('token');
        if($token == null){
            return redirect('/auth');
        }
        if(!$user = User::where('token',$token)->first()){
            return redirect('/auth');
        }
        if($user->role_id != 1){
            return redirect('/');
        }
        $posts = Post::all();
        return view('console',['posts' => $posts]);
    }

    public function acConsoleUpdate($id){
        $post = Post::where('id', $id)->first();
        return view('update',['post'=>$post]);
    }

    public function acConsoleAdd(Request $request){
        $post = Post::create([
            'date' => date('Y-m-d H:i:s'),
            'content' => $request->input('content'),
            'title' => $request->input('title'),
            'img' => $request->input('img'),
            'name'=> $request->input('name'),
            'parent' => $request->input('parent'),
            'guid' => 0,
            'allowed' => 1
        ]);
        return "Запись добавлена!";
    }

    public function adminMod(Request $request){
        $post = Post::find($request->input('id'));
        $post->content = $request->input('content');
        $post->title = $request->input('title');
        $post->name = $request->input('name');
        $post->save();
        return "Запись изменена!";
    }

    public function adminDelete($id){
        $post = Post::find($id);
        $post->delete();
        return "Запись $post->title удалена!";
    }
}
