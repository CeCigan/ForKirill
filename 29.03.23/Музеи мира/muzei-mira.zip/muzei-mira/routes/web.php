<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/', [MainController::class, 'acGlavnaya']);
Route::get('/velikie-muzei', [MainController::class, 'acVelikieMuzei']);
Route::get('/velikie-muzei/{submuzei}', [MainController::class, 'acSubMuzei']);
Route::get('/novosti', [MainController::class, 'acNovosti']);
Route::get('/zhivopis', [MainController::class, 'acZhivopis']);
Route::get('/zhivopis/{subzhivopis}', [MainController::class, 'acSubZhivopis']);
Route::get('/skulptura', [MainController::class, 'acSkulptura']);
Route::get('/skulptura/{subskulptura}', [MainController::class, 'acSubSkulptura']);
Route::get('/goroda', [MainController::class, 'acGoroda']);
Route::get('/goroda/{subgorod}', [MainController::class, 'acSubGoroda']);
Route::get('/neobychnye-muzei-mira', [MainController::class, 'acNMM']);
Route::get('/neobychnye-muzei-mira/{subNMM}', [MainController::class, 'acSubNMM']);

Route::get('/console',[AdminController::class,'acConsole']);
Route::get('/console/update/{id}', [AdminController::class, 'acConsoleUpdate']);
Route::post('/console/add', [AdminController::class, 'acConsoleAdd']);
Route::post('/admin/modification',[AdminController::class, 'adminMod']);
Route::get('/admin/delete/{id}',[AdminController::class, 'adminDelete']);

Route::get('/auth',[UserController::class, 'loginPage']);
Route::post('/auth',[UserController::class, 'loginUser']);
Route::get('/register',[UserController::class, 'registerPage']);
Route::post('/register',[UserController::class, 'registerUser']);
Route::get('/logout',[UserController::class, 'logoutUser']);

Route::get('/cart',[UserController::class, 'cart']);
Route::get('/cart/delete/{id}',[UserController::class, 'cartDelete']);
Route::get('/cart/add/{id}',[UserController::class, 'cartAdd']);