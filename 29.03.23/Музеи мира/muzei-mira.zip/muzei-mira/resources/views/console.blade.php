<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <link rel="stylesheet" href="{{asset('/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('/css/app.css')}}">
    <!-- <link rel="stylesheet" href="{{asset('/css/main.css')}}"> -->
</head>
<body>
<header>
        <!-- <img src="{{asset('/images/header-bckgr.jpg')}}" alt="header"> -->
        <div>
            <h1>
                Музеи Мира
            </h1>    
        </div>
        <div>
            <h2>Виртуальная экскурсия</h2>
        </div>
    </header>
    <nav>
        <ul class="menu">
            <li>
                <a href="/" class="nav__item">Главная</a>
            </li>
            <li>
                <a href="/velikie-muzei/" class="nav__item">Великие музеи</a>
            </li>
            <li>
                <a href="/novosti" class="nav__item">Новости</a>
            </li>
            <li>
                <a href="/zhivopis" class="nav__item">Живопись</a>
            </li>
            <li>
                <a href="/skulptura" class="nav__item">Скульптура</a>
            </li>
            <li>
                <a href="/goroda" class="nav__item">Города</a>
            </li>
            <li>
                <a href="/neobychnye-muzei-mira" class="nav__item">Необычные музеи</a>
            </li>
            <li>
                <a href="/console" class="nav__item">Консоль</a>
            </li>
            <li>
                <a href="/cart">Корзина</a>
            </li>
            <li>
                <a href="/logout">Выйти</a>
            </li>
        </ul>
    </nav>
    <main>
        <div class="wrapper">
            <h1>Консоль</h1>
            <div class="content">
                @if ($posts)
                <h2>Изменить пост</h5>
                <ul>
                    @foreach ($posts as $post)
                    <li>
                        <a href="/console/update/{{$post->id}}">{{$post->title}}</a>
                        <a href="/admin/delete/{{$post->id}}">[Удалить]</a>
                    </li>
                    @endforeach
                </ul>
                @endif
                <h2>Добавить пост</h2>
                <form method="POST" action="/console/add">
                    @csrf
                    <input required type="text" name='title' placeholder="title">
                    <textarea required name="content" placeholder="content" cols="30" rows="10"></textarea>
                    <input required type="text" name="name" placeholder="name">
                    <input required type="text" name="img" placeholder="img">
                    <input required type="text" name="parent" placeholder="parent">
                    <input type="submit" value="Добавить">
                </form>
            </div>
        </div>
    </main>
    <footer>
        <div class="footer__info">Музеи Мира</div>
    </footer>
    <script src="{{asset('/js/app.js')}}"></script>
</body>
</html>