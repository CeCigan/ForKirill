<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::connection('mysql2')->create('posts', function (Blueprint $table) {
            $table->id();
            $table->date('date');
            $table->string('content');
            $table->string('title');
            $table->string('img');
            $table->string('name');
            $table->bigInteger('parent');
            $table->bigInteger('guid')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::connection('mysql2')->dropIfExists('posts');
    }
};
