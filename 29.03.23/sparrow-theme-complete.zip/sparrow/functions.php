<?php 
    add_action('wp_enqueue_scripts', 'style_theme');
    add_action('wp_enqueue_scripts', 'scripts_theme');
    add_action('after_setup_theme', 'myMenu');

    function style_theme(){
        wp_enqueue_style('style', get_stylesheet_uri());
        wp_enqueue_style('default', get_template_directory_uri() . '/assets/css/default.css');
        wp_enqueue_style('layout', get_template_directory_uri() . '/assets/css/layout.css');
        wp_enqueue_style('media-quaries', get_template_directory_uri() . '/assets/css/media-quaries.css');
        wp_enqueue_style('fonts', get_template_directory_uri() . '/assets/css/fonts.css');
    }

    function scripts_theme(){
        wp_enqueue_script('doubletaptogo', get_template_directory_uri() . '/assets/js/doubletaptogo.js');
        wp_enqueue_script('init', get_template_directory_uri() . '/assets/js/init.js');
        wp_enqueue_script('jquery', get_template_directory_uri() . '/assets/js/jquery-1.10.2.min.js');
        wp_enqueue_script('migrate', get_template_directory_uri() . '/assets/js/jquery-migrate-1.2.1.min.js');
        wp_enqueue_script('flexslider', get_template_directory_uri() . '/assets/js/jquery.flexslider.js');
        wp_enqueue_script('modernizr', get_template_directory_uri() . '/assets/js/modernizr.js'); 
    }

    function myMenu(){
        register_nav_menu('topMenu', 'Меню шапки');
        register_nav_menu('footerMenu', 'Меню подвала');
        register_nav_menu('footerListsMenu', 'Меню навигации подвала');
    }
?>