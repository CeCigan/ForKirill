<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>"> -->
</head>
<body>
<header>
        <!-- <img src="<?php echo e(asset('/images/header-bckgr.jpg')); ?>" alt="header"> -->
        <div>
            <h1>
                Музеи Мира
            </h1>    
        </div>
        <div>
            <h2>Виртуальная экскурсия</h2>
        </div>
    </header>
    <nav>
        <ul class="menu">
            <li>
                <a href="/" class="nav__item">Главная</a>
            </li>
            <li>
                <a href="/velikie-muzei/" class="nav__item">Великие музеи</a>
            </li>
            <li>
                <a href="/novosti" class="nav__item">Новости</a>
            </li>
            <li>
                <a href="/zhivopis" class="nav__item">Живопись</a>
            </li>
            <li>
                <a href="/skulptura" class="nav__item">Скульптура</a>
            </li>
            <li>
                <a href="/goroda" class="nav__item">Города</a>
            </li>
            <li>
                <a href="/neobychnye-muzei-mira" class="nav__item">Необычные музеи</a>
            </li>
            <li>
                <a href="/console" class="nav__item">Консоль</a>
            </li>
        </ul>
    </nav>
    <main>
        <div class="wrapper">
            <h1>Регистрация</h1>
            <div class="content">
                <form method="POST" action="/register">
                    <?php echo csrf_field(); ?>
                    <input required type="text" name='login' placeholder="login">
                    <input required type="password" name='password' placeholder="password">
                    <input required type="text" name='name' placeholder="name">
                    <input type="submit" value="Регистрация">
                    <a style="font-size: 24px; color: black;" href="/auth">Авторизация</a>
                </form>
            </div>
        </div>
    </main>
    <footer>
        <div class="footer__info">Музеи Мира</div>
    </footer>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\muzei-mira\resources\views/register.blade.php ENDPATH**/ ?>