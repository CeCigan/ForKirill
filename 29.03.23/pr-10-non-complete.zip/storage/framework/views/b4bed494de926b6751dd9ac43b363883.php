<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
</head>
<body>
    <header>
        <!-- <img src="<?php echo e(asset('/images/header-bckgr.jpg')); ?>" alt="header"> -->
        <div>
            <h1>
                Музеи Мира
            </h1>    
        </div>
        <div>
            <h2>Виртуальная экскурсия</h2>
        </div>
    </header>
    <nav>
        <ul class="menu">
            <li>
                <a href="/" class="nav__item">Главная</a>
            </li>
            <li>
                <a href="/velikie-muzei/" class="nav__item">Великие музеи</a>
                <?php if($otherMuzei): ?>
                    <ul class="submenu">
                        <?php $__currentLoopData = $otherMuzei; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="/velikie-muzei/<?php echo e($post->name); ?>"><?php echo e($post->title); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
            <li>
                <a href="/novosti" class="nav__item">Новости</a>
            </li>
            <li>
                <a href="/zhivopis" class="nav__item">Живопись</a>
                <?php if($otherZhivopis): ?>
                    <ul class="submenu">
                        <?php $__currentLoopData = $otherZhivopis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="/zhivopis/<?php echo e($post->name); ?>"><?php echo e($post->title); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
            <li>
                <a href="/skulptura" class="nav__item">Скульптура</a>
                <?php if($otherSkulptura): ?>
                    <ul class="submenu">
                        <?php $__currentLoopData = $otherSkulptura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="/skulptura/<?php echo e($post->name); ?>"><?php echo e($post->title); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
            <li>
                <a href="/goroda" class="nav__item">Города</a>
                <?php if($otherGoroda): ?>
                    <ul class="submenu">
                        <?php $__currentLoopData = $otherGoroda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="/goroda/<?php echo e($post->name); ?>"><?php echo e($post->title); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
            <li>
                <a href="/neobychnye-muzei-mira" class="nav__item">Необычные музеи</a>
                <?php if($otherNmm): ?>
                    <ul class="submenu">
                        <?php $__currentLoopData = $otherNmm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="/neobychnye-muzei-mira/<?php echo e($post->name); ?>"><?php echo e($post->title); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
            <li>
                <a href="/console" class="nav__item">Консоль</a>
            </li>
        </ul>
    </nav>
    
    <main>
        <div class="wrapper">
            <div class="content">
                <h1><?php echo e($title); ?></h1>
                    <?php echo $content; ?>

                    <img src="<?php echo e(asset('/images/asset')); ?>/<?php echo e($img); ?>" alt="">
                    <?php if($posts): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($post->parent == 3): ?>
                                <h2 align=center>
                                    <?php echo e($post->title); ?>

                                </h2>
                                <div>
                                    <?php echo e($post->content); ?>

                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <div>
            <p>
                Музеи Мира
            </p>    
        </div>
    </footer>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\makeevsky-muzei\muzei_mira\resources\views/app.blade.php ENDPATH**/ ?>