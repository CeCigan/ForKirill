<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>"> -->
</head>
<body>
<header>
        <!-- <img src="<?php echo e(asset('/images/header-bckgr.jpg')); ?>" alt="header"> -->
        <div>
            <h1>
                Музеи Мира
            </h1>    
        </div>
        <div>
            <h2>Виртуальная экскурсия</h2>
        </div>
    </header>
    <nav>
        <ul class="menu">
            <li>
                <a href="/" class="nav__item">Главная</a>
            </li>
            <li>
                <a href="/velikie-muzei/" class="nav__item">Великие музеи</a>
            </li>
            <li>
                <a href="/novosti" class="nav__item">Новости</a>
            </li>
            <li>
                <a href="/zhivopis" class="nav__item">Живопись</a>
            </li>
            <li>
                <a href="/skulptura" class="nav__item">Скульптура</a>
            </li>
            <li>
                <a href="/goroda" class="nav__item">Города</a>
            </li>
            <li>
                <a href="/neobychnye-muzei-mira" class="nav__item">Необычные музеи</a>
            </li>
            <li>
                <a href="/console" class="nav__item">Консоль</a>
            </li>
        </ul>
    </nav>
    <main>
        <div class="wrapper">   
            <div class="content">
                <h1>Изменить пост</h1>
                <form method="POST" action="/admin/modification">
                <?php echo csrf_field(); ?>
                    <input type="number" name="id" readonly value="<?php echo e($post->id); ?>">    
                    <textarea name="content" placeholder="content" cols="30" rows="10"><?php echo e($post->content); ?></textarea>
                    <input type="text" name='title' placeholder="title" value="<?php echo e($post->title); ?>">
                    <input type="text" name="name" placeholder="name" value="<?php echo e($post->name); ?>">
                    <input type="text" name="img" placeholder="img" value="<?php echo e($post->img); ?>">
                    <input type="text" name="parent" placeholder="parent" value="<?php echo e($post->parent); ?>">
                    <input type="submit" value="Обновить">
                </form>
            </div>
        </div>
    </main>
    <footer>
        <div class="footer__info">Музеи Мира</div>
    </footer>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\muzei-mira\resources\views/update.blade.php ENDPATH**/ ?>