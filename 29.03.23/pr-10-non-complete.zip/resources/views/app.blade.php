<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <!-- <link rel="stylesheet" href="{{asset('/css/main.css')}}"> -->
    <link rel="stylesheet" href="{{asset('/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('/css/app.css')}}">
</head>
<body>
    <header>
        <!-- <img src="{{asset('/images/header-bckgr.jpg')}}" alt="header"> -->
        <div>
            <h1>
                Музеи Мира
            </h1>    
        </div>
        <div>
            <h2>Виртуальная экскурсия</h2>
        </div>
    </header>
    <nav>
        <ul class="menu">
            <li>
                <a href="/" class="nav__item">Главная</a>
            </li>
            <li>
                <a href="/velikie-muzei/" class="nav__item">Великие музеи</a>
                @if ($otherMuzei)
                    <ul class="submenu">
                        @foreach ($otherMuzei as $post)
                        <li>
                            <a href="/velikie-muzei/{{$post->name}}">{{$post->title}}</a>
                        </li>
                        @endforeach
                    </ul>
                @endif
            </li>
            <li>
                <a href="/novosti" class="nav__item">Новости</a>
            </li>
            <li>
                <a href="/zhivopis" class="nav__item">Живопись</a>
                @if ($otherZhivopis)
                    <ul class="submenu">
                        @foreach ($otherZhivopis as $post)
                        <li>
                            <a href="/zhivopis/{{$post->name}}">{{$post->title}}</a>
                        </li>
                        @endforeach
                    </ul>
                @endif
            </li>
            <li>
                <a href="/skulptura" class="nav__item">Скульптура</a>
                @if ($otherSkulptura)
                    <ul class="submenu">
                        @foreach ($otherSkulptura as $post)
                        <li>
                            <a href="/skulptura/{{$post->name}}">{{$post->title}}</a>
                        </li>
                        @endforeach
                    </ul>
                @endif
            </li>
            <li>
                <a href="/goroda" class="nav__item">Города</a>
                @if ($otherGoroda)
                    <ul class="submenu">
                        @foreach ($otherGoroda as $post)
                        <li>
                            <a href="/goroda/{{$post->name}}">{{$post->title}}</a>
                        </li>
                        @endforeach
                    </ul>
                @endif
            </li>
            <li>
                <a href="/neobychnye-muzei-mira" class="nav__item">Необычные музеи</a>
                @if ($otherNmm)
                    <ul class="submenu">
                        @foreach ($otherNmm as $post)
                        <li>
                            <a href="/neobychnye-muzei-mira/{{$post->name}}">{{$post->title}}</a>
                        </li>
                        @endforeach
                    </ul>
                @endif
            </li>
            <li>
                <a href="/console" class="nav__item">Консоль</a>
            </li>
        </ul>
    </nav>
    
    <main>
        <div class="wrapper">
            <div class="content">
                <h1>{{$title}}</h1>
                    {!!$content!!}
                    <img src="{{asset('/images/asset')}}/{{$img}}" alt="">
                    @if ($posts)
                        @foreach ($posts as $post)
                            @if($post->parent == 3)
                                <h2 align=center>
                                    {{$post->title}}
                                </h2>
                                <div>
                                    {{$post->content}}
                                </div>
                            @endif
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </main>
    <footer>
        <div>
            <p>
                Музеи Мира
            </p>    
        </div>
    </footer>
    <script src="{{asset('/js/app.js')}}"></script>
</body>
</html>