<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <link rel="stylesheet" href="{{asset('/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('/css/app.css')}}">
    <!-- <link rel="stylesheet" href="{{asset('/css/main.css')}}"> -->
</head>
<body>
<header>
        <!-- <img src="{{asset('/images/header-bckgr.jpg')}}" alt="header"> -->
        <div>
            <h1>
                Музеи Мира
            </h1>    
        </div>
        <div>
            <h2>Виртуальная экскурсия</h2>
        </div>
    </header>
    <nav>
        <ul class="menu">
            <li>
                <a href="/" class="nav__item">Главная</a>
            </li>
            <li>
                <a href="/velikie-muzei/" class="nav__item">Великие музеи</a>
            </li>
            <li>
                <a href="/novosti" class="nav__item">Новости</a>
            </li>
            <li>
                <a href="/zhivopis" class="nav__item">Живопись</a>
            </li>
            <li>
                <a href="/skulptura" class="nav__item">Скульптура</a>
            </li>
            <li>
                <a href="/goroda" class="nav__item">Города</a>
            </li>
            <li>
                <a href="/neobychnye-muzei-mira" class="nav__item">Необычные музеи</a>
            </li>
            <li>
                <a href="/console" class="nav__item">Консоль</a>
            </li>
        </ul>
    </nav>
    <main>
        <div class="wrapper">   
            <div class="content">
                <h1>Изменить пост</h1>
                <form method="POST" action="/admin/modification">
                @csrf
                    <input type="number" name="id" readonly value="{{$post->id}}" >    
                    <textarea name="content" placeholder="content" cols="30" rows="10">{{$post->content}}</textarea>
                    <input type="text" name='title' placeholder="title" value="{{$post->title}}">
                    <input type="text" name="name" placeholder="name" value="{{$post->name}}">
                    <input type="file" name="img" placeholder="img" value="{{$post->img}}">
                    <input type="text" name="parent" placeholder="parent" value="{{$post->parent}}">
                    <input type="submit" value="Обновить">
                </form>
                {{-- @if ($massage)
                     <b>Запись обновлена</b>
                @else
                    <b></b>
                @endif --}}
            </div>
        </div>
    </main>
    <footer>
        <div class="footer__info">Музеи Мира</div>
    </footer>
    <script src="{{asset('/js/app.js')}}"></script>
</body>
</html>