<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class User extends Model
{
    public $timestamps = false;
    use HasFactory;
    public function trips()
    {
        return $this->belongsToMany(Trip::class);
    }
    protected $fillable = [
        'login',
        'password',
        'role_id',
        'name',
    ];
}
