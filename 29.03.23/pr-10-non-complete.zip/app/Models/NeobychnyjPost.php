<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NeobychnyjPost extends Model
{
    public $timestamps = false;
    use HasFactory;
    protected $connection = 'mysql2';
    protected $table = 'posts';
    protected $fillable = [
        'date',
        'content',
        'title',
        'img',
        'name',
        'parent',
        'guid',
    ];
}
