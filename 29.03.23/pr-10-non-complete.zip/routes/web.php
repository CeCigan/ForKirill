<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Контроллер контента страницы
Route::get('/', [MainController::class, 'getMainPage']);
Route::get('/velikie-muzei', [MainController::class, 'getVelikieMuzei']);
Route::get('/velikie-muzei/{submuzei}', [MainController::class, 'getSubMuzei']);
Route::get('/novosti', [MainController::class, 'getNews']);
Route::get('/zhivopis', [MainController::class, 'getGalery']);
Route::get('/zhivopis/{subzhivopis}', [MainController::class, 'getSubGalery']);
Route::get('/skulptura', [MainController::class, 'getSculptures']);
Route::get('/skulptura/{subskulptura}', [MainController::class, 'getSubSculptures']);
Route::get('/goroda', [MainController::class, 'getCityes']);
Route::get('/goroda/{subgorod}', [MainController::class, 'getSubCityes']);
Route::get('/neobychnye-muzei-mira', [MainController::class, 'getNMM']);
Route::get('/neobychnye-muzei-mira/{subNMM}', [MainController::class, 'getSubNMM']);

// Контроллер админа
Route::get('/console',[AdminController::class,'startConsole']);
Route::get('/console/update/{id}', [AdminController::class, 'ConsoleUpdate']);
Route::post('/console/add', [AdminController::class, 'ConsoleAdd']);
Route::post('/admin/modification',[AdminController::class, 'adminMod']);
Route::get('/admin/delete/{id}',[AdminController::class, 'adminDelete']);
