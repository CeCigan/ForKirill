
(function() {
    var MARKETING_COOKIE_NAME = 'skyeng_mData';
    var ANALYTICS_SUB = 'analytics.';
    var PROTOCOL = 'https://';

    var MARKETING_DATA_URL = '/open-api/v1/save-marketing-data';

    var testHost = location.hostname.match('test-y([0-9]+)');

    if (testHost && testHost.length) {
        var hostNumber = testHost[1];
        MARKETING_COOKIE_NAME = MARKETING_COOKIE_NAME +  '_y' + hostNumber;
    }

    var mainHost = 'skyeng.ru';
    var isTest = !!location.hostname.match('test');
    var HOST = PROTOCOL + ANALYTICS_SUB;

    if (isTest) {
        var hostParts = location.hostname.split('.');
        //something like id.test.skyeng.ru
        if (hostParts.length > 3) {
            hostParts.shift();
        }

        HOST += hostParts.join('.');
    } else {
        HOST += mainHost;
    }

    /**
     * @param url
     * @param body
     * @param callback
     */
    function ajaxSend(url, body, callback) {
        var xhttp;
        xhttp=new XMLHttpRequest();
        xhttp.withCredentials = true;
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                callback(this);
            }
        };
        xhttp.open("POST", url, true);
        xhttp.setRequestHeader('Content-Type', 'text/plain');
        xhttp.send(body);
    }

    /**
     *
     * @param name
     * @param value
     * @param options
     */
    function setCookie(name, value, options) {
        options = options || {};

        var expires = options.expires;

        if (typeof expires == "number" && expires) {
            var d = new Date();
            d.setTime(d.getTime() + expires * 1000);
            expires = options.expires = d;
        }
        if (expires && expires.toUTCString) {
            options.expires = expires.toUTCString();
        }

        if (!options["domain"]) {
            var h = location.hostname.split('.');
            var numSubDomains = 2;
            var isTest = location.hostname.match('test');

            if (!!isTest) {
                numSubDomains = 3;
            }

            while(h.length > numSubDomains) {
                h.shift();
            }

            options["domain"] = h.join(".");
        }

        value = encodeURIComponent(value);

        var updatedCookie = name + "=" + value;

        for (var propName in options) {
            updatedCookie += "; " + propName;
            var propValue = options[propName];
            if (propValue !== true) {
                updatedCookie += "=" + propValue;
            }
        }

        document.cookie = updatedCookie;
    }

    /**
     * Достаёт cookie по ключу
     * @param cname
     * @returns {*}
     */
    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for(var i = 0; i <ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    /**
     * Возвращает cookie как объект
     * @returns {object}
     */
    function getAllCookies() {
        var pairs = document.cookie.split(/; */);
        var cookies = {};

        if (0 === pairs.length) {
            return;
        }

        for (var i = 0; i < pairs.length; i++){
            var pair = pairs[i].split("=");
            cookies[pair[0]] = decodeURIComponent(pair[1]);
        }

        return cookies;
    }

    /**
     * Подготавливает маркетинговые данные
     */
    function prepareMarketingData()
    {
        var data = {
            referer: window.document.referrer,
            cookie: getAllCookies(),
        };

        var guestUid = getCookie(MARKETING_COOKIE_NAME);
        if (guestUid) {
            data['guestUid'] = guestUid;
        }

        return data;
    }

    ajaxSend(HOST + MARKETING_DATA_URL, JSON.stringify(prepareMarketingData()), function(rData) {
        var d = JSON.parse(rData.responseText);
        if (!d.hasOwnProperty("guestUid")) {
            return;
        }
        setCookie(MARKETING_COOKIE_NAME, d.guestUid, {"expires": 31556926, "path": "/"});
    });

})();
