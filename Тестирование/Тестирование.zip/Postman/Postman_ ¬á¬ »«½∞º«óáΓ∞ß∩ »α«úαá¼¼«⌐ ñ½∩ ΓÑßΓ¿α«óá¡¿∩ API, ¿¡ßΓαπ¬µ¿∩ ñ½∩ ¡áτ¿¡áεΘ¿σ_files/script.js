var $ = jQuery;


var swiper_webinars = new Swiper('.swiper_webinars', {
    // Optional parameters
    direction: 'horizontal',
    loop: false,
    slidesPerView: 'auto',
    spaceBetween: 40,
    freeMode: true,
    navigation: {
        nextEl: '.webinar_btn_next',
        prevEl: '.webinar_btn_prev',
    },
    breakpoints: {
        1: {
            slidesPerView: 'auto',
            spaceBetween: 24,
            freeMode: true,
        },
        650: {
            slidesPerView: 2,
            spaceBetween: 24,
        },
        993: {
            slidesPerView: 'auto',
            spaceBetween: 40,
        },
    }
});

var swiper_webinars_article = new Swiper('.article_item .swiper_webinars', {
    direction: 'horizontal',
    loop: false,
    slidesPerView: 1,
    spaceBetween: 24,
    freeMode: true,
    navigation: {
        nextEl: '.webinar_btn_next',
        prevEl: '.webinar_btn_prev',
    },
    breakpoints: {
        1: {
            slidesPerView: 'auto',
            spaceBetween: 24,
        },
        650: {
            slidesPerView: 'auto',
            spaceBetween: 24,
        },
        993: {
            slidesPerView: 2,
            spaceBetween: 24,
        },
    }
});

var swiper_list = $("[data-slider-id]");
$(swiper_list).each(function() {
    let swiper_slide_id = $(this).attr('data-slider-id');
    console.log(swiper_slide_id)
    var article_swiper_thumb = new Swiper('.article_swiper_thumb' + swiper_slide_id, {
        direction: 'horizontal',
        loop: false,
        slidesPerView: 6,
        spaceBetween: 16,
        freeMode: true,
        watchSlidesProgress: true,
        breakpoints: {
            1: {
                slidesPerView: 'auto',
                spaceBetween: 24,
                freeMode: true,
            },
            650: {
                slidesPerView: 5,
                spaceBetween: 8,
            },
            993: {
                slidesPerView: 6,
                spaceBetween: 16,
            },
        }
    });
    var article_swiper_big = new Swiper('.article_swiper_big' + swiper_slide_id, {
        direction: 'horizontal',
        loop: false,
        slidesPerView: 1,
        spaceBetween: 0,
        navigation: {
            nextEl: '.article_swiper_btn_next',
            prevEl: '.article_swiper_btn_prev',
        },
        thumbs: {
            swiper: article_swiper_thumb,
        },
        on: {
            init: function() {
                $('.article_swiper_big').each(function() {
                    let caption = $(this).find('.swiper-slide-active .caption_slide').html()
                    $(this).parent().find('figcaption').html(caption)
                })
            }
        }
    });

    article_swiper_big.on('slideChangeTransitionEnd', function() {
        $('.article_swiper_big').each(function() {
            let caption = $(this).find('.swiper-slide-active .caption_slide').html()
            $(this).parent().find('figcaption').html(caption)
        })
    })
})

var swiper_article_category = new Swiper('.swiper_article_category', {
    direction: 'horizontal',
    loop: false,
    slidesPerView: 3,
    spaceBetween: 48,
    navigation: {
        nextEl: '.article_head_btn_next',
        prevEl: '.article_head_btn_prev',
    },
    breakpoints: {
        1: {
            slidesPerView: 1,
            spaceBetween: 24,
            freeMode: true,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 32,
        },
        1100: {
            slidesPerView: 3,
            spaceBetween: 48,
        },
    }
});

$('.header .burger_btn').on('click', function() {
    $(this).toggleClass('active')
    $('.header .burger_menu').toggleClass('active')
    $('.header').toggleClass('active')
    $('html').toggleClass('lock')
});

$('.header_sticky .burger_btn').on('click', function() {
    $(this).toggleClass('active')
    $('.header_sticky .burger_menu').toggleClass('active')
    $('.header_sticky').toggleClass('open')
    $('.header').toggleClass('active')
    $('html').toggleClass('lock')
});

// Фикс шапка

var block_show = null;

function scrollTracking() {
    var wt = $(window).scrollTop();
    var wh = $(window).height();
    var et = $('.header').offset().top;
    var eh = $('.header').outerHeight();

    if (wt + wh >= et && wt + wh - eh * 2 <= et + (wh - eh)) {
        if (block_show == null || block_show == false) {
            $('.header_sticky').removeClass('active')
        }
        block_show = true;
    } else {
        if (block_show == null || block_show == true) {
            $('.header_sticky').addClass('active')
        }
        block_show = false;
    }
}

$(window).scroll(function() {
    scrollTracking();
});

$(document).ready(function() {
    scrollTracking();
});

$('.author_theme_item').on('click', function() {
    $('.author_theme_item').removeClass('active')
    $(this).addClass('active')
})

$('.header .search_icon').on('click', function() {
    $('.search_block').addClass('active')
    $('.header_nav').addClass('visible')
    $('.header').addClass('active')
})

$('.header .seacrh_icon_close').on('click', function() {
    $('.search_block').removeClass('active')
    $('.header_nav').removeClass('visible')
    $('.header').addClass('active')
})

$('.header_sticky .search_icon').on('click', function() {
    $('.search_block').addClass('active')
    $('.header_nav').addClass('visible')
    $('.header').addClass('active')
})

$('.header_sticky .seacrh_icon_close').on('click', function() {
    $('.search_block').removeClass('active')
    $('.header_nav').removeClass('visible')
    $('.header').addClass('active')
})

$('.header .search_val').on("change input", function() {
    let search_value = $(this).val();
    if ($(this).val().length > 2) {

        $.ajax({
            url: "/media/wp-admin/admin-ajax.php",
            type: "POST",
            data: {
                "action": "ajax_search", // functions.php
                "term": search_value
            },
            success: function(results) {
                $('.header .header_search_list').addClass('active');
                $('.header .header_search_list').html(results);
            }
        });
    } else {
        $('.header .header_search_list').removeClass('active');
    }
});

$('.header_sticky .search_val').on("change input", function() {

    let search_value = $(this).val();
    if ($(this).val().length > 2) {

        $.ajax({
            url: "/media/wp-admin/admin-ajax.php",
            type: "POST",
            data: {
                "action": "ajax_search", // functions.php
                "term": search_value
            },
            success: function(results) {
                $('.header_sticky .header_search_list').addClass('active');
                $('.header_sticky .header_search_list').html(results);
            }
        });
    } else {
        $('.header_sticky .header_search_list').removeClass('active');
    }



});

$(document).mouseup(function(e) {
    var container = $(".search_block");
    if (container.has(e.target).length === 0) {
        container.removeClass('active');
    }
    if (container.hasClass('active')) {
        $('.header_nav').addClass('visible')
    } else {
        $('.header_nav').removeClass('visible')
    }
});

$(document).mouseup(function(e) {
    var container = $(".header_search_list");
    if (container.has(e.target).length === 0) {
        container.removeClass('active');
    }
});

$(".open-modal").on("click", function() {
    $('[data-modal="' + $(this).data('modal') + '"]').addClass("open");
});

$(".close-modal").on("click", function() {
    $('[data-modal="' + $(this).data('modal') + '"]').removeClass("open");
});


$(document).mouseup(function(e) {
    var container = $(".popup_thx");
    if (container.has(e.target).length === 0) {
        container.removeClass('open');
    }
});

$('.article_accordion_item').on('click', function() {
    $(this).toggleClass('active')
    $(this).find('.article_accordion_item_title').next().slideToggle(300)
})

$('.article_menu ul li a').on('click', function() {
    $('.article_menu ul li a').removeClass('active')
    $(this).addClass('active')
});



$('.subscribe_btn').on('mousedown', function() {
    $(this).css('background', '#FFD7D6')
});

$('.subscribe_btn').on('mouseup', function() {
    $(this).css('background', '#FF9E00')
});

$(document).ready(function() {

    /*Делаем плавную прокрутку при клике на якорную ссылку:*/
    $(function() {
        var curlvl;
        var startlvl = 0;
        var prevlvl = startlvl;
        var lst = $("#toc");

        var href1 = window.location.href;

        var href2 = href1.replace(window.location.hash, "");
        if (typeof lst !== "undefined") {
            $(".article_text h2").each(function(i) {
                var current = $(this);
                current.attr("id", "title" + i);
                for (curlvl = parseInt(current.prop("tagName").substring(1)); curlvl > prevlvl; prevlvl++) {
                    var tmp = $("<ul></ul>");
                    if (prevlvl == startlvl)
                        lst.append(tmp);
                    else {
                        var last_li = $("#toc li").last();
                        last_li.append(tmp);
                    }
                    if (curlvl > prevlvl + 1)
                        tmp.append("<li style=\"list-style-type: none\"></li>");
                    lst = tmp;
                }
                while (curlvl < prevlvl) {
                    lst = lst.parent().parent();
                    prevlvl--;
                }
                curder = current.html();
                if (curder.charAt(curder.length - 1) == ':') {
                    curder = curder.substr(0, curder.length - 1);
                }

                lst.append("<li><a id='link" + i + "' itemprop='url' href='" + href2 + "#title" + i + "' title='" + current.html() + "' class='contente_item'>" + curder + "</a></li>");
            });
            $('.mobile_nav_post').html($('#toc').html());

        }

        if ($('#toc li').length == 0) {
            $('#toc').css('display', 'none');
        }
    });
});


Fancybox.bind('[data-custom="custom"], .wp-caption a', {
    Carousel: {
        Navigation: {
            prevTpl: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M11 5l-7 7 7 7"/><path d="M4 12h16"/></svg>',
            nextTpl: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M4 12h16"/><path d="M13 5l7 7-7 7"/></svg>',
        },
    },
    Thumbs: {
        autoStart: false,
    },
    Toolbar: {
        display: [{
                id: "counter",
                position: "center"
            },
            "close",
        ],
    },

});

Fancybox.defaults.ScrollLock = false;

$('input[type="tel"]').inputmask("+7 (999) 999 99 99");

document.addEventListener('wpcf7mailsent', function(event) {

    if (event.detail.contactFormId == '1246') {
        $('.subscribe_btn_block input').addClass('active')
        $('.subscribe_btn_block input').val('Ты с нами, круто!')
        $('.subscribe_btn_block').addClass('active')
        $('.popup_thx').addClass('open');
    } else if (event.detail.contactFormId == '1261') {
        console.log('test');
        $('.popup_thx').addClass('open');
    } else {
        $('.popup_thx_s').addClass('open');
    }



}, false);



function bannerCall() {
    $('.popup_banner').addClass('open')
}

function heightBanner() {
    let hb = $('.popup_banner').height();
    $('body').css('margin-top', hb)
    bannerCall()
    if ($(window).width() < 650) {
        let hb = $('.popup_banner').height() + 10;
        let top = 10;
        $('.popup_banner').css('top', top)
        $('body').css('margin-top', hb)
    }
}

setTimeout(heightBanner, 1000)





$('.copylink').on('click', function() {
    let url = document.location.href + '?utm_source=skypro_blog&utm_medium=free&utm_campaign=n_share%7Cpl_groupITbutton%7Cpr_78%7Cta_%7Cfu_product%7Cma_%7Cown_b2c%7Ccnt_RU%7Cbr_Skypro%7Cchg_skypro_blog'

    navigator.clipboard.writeText(url).then(function() {
        console.log('Copied!');
    }, function() {
        console.log('Copy error')
    });
    return false;
})


$('.uslugi_page_wrapper_item').each(function() {
    if ($(this).find('.uslugi_page_wrapper_item_text p').length < 1) {
        $(this).find('.accordion').css('display', 'none');
    }
})