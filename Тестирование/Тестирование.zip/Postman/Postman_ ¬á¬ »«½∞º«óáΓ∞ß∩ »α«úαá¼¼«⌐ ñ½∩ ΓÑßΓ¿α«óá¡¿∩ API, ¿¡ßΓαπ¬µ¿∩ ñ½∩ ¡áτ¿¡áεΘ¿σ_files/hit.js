
(function(window) {
    var SETH_COOKIE_NAME_SKYENG = '_seid';
    var SETH_COOKIE_NAME_GOOGLE = '_ga';
    var SETH_COOKIE_NAME_YANDEX = '_ym_uid';
    var SETH_COOKIE_NAME_SKYENG_TIMEZONE = '_setz';
    var SETH_COOKIE_NAME_SKYENG_OLD = 'skyeng_mData';
    var SETH_HIT_COLLECT_URL = '/track-hits/hit/collect';
    var SETH_HIT_UPDATE_URL = '/track-hits/hit/update';
    var currentHitId = undefined;
    var lastCollectedHref = null;

    function prepareUrl(path) {
        var current_host = location.hostname;
        var is_production = !current_host.match('test-y([0-9]+).skyeng.link') && !current_host.match('skyeng.loc');
        var base_host;
        if (is_production) {
            base_host = 'skyeng.ru'
        } else {
            var max_length = current_host.match('skyeng.loc') ? 2 : 3;
            var host_parts = current_host.split('.');
            if (host_parts.length > max_length) {
                host_parts.shift();
            }
            base_host = host_parts.join('.')
        }
        return 'https://marketing-core.' + base_host + path;
    }

    // https://github.com/js-cookie/js-cookie/blob/v2.2.0/src/js.cookie.js
    function get_cookie(key) {
        var result;
        if (!key) {
            result = {};
        }
        var cookies = document.cookie ? document.cookie.split('; ') : [];
        var rdecode = /(%[0-9A-Z]{2})+/g;
        var i = 0;
        for (; i < cookies.length; i++) {
            var parts = cookies[i].split('=');
            var cookie = parts.slice(1).join('=');
            if (cookie.charAt(0) === '"') {
                cookie = cookie.slice(1, -1);
            }
            try {
                var name = parts[0].replace(rdecode, decodeURIComponent);
                cookie = cookie.replace(rdecode, decodeURIComponent);
                if (key === name) {
                    result = cookie;
                    break;
                }
                if (!key) {
                    result[name] = cookie;
                }
            } catch (e) {}
        }
        return result;
    }
    function set_cookie(key, value, attributes) {
        if (typeof attributes.expires === 'number') {
            var expires = new Date();
            expires.setMilliseconds(expires.getMilliseconds() + attributes.expires * 864e+5);
            attributes.expires = expires;
        }

        // We're using "expires" because "max-age" is not supported by IE
        attributes.expires = attributes.expires ? attributes.expires.toUTCString() : '';

        try {
            result = JSON.stringify(value);
            if (/^[\{\[]/.test(result)) {
                value = result;
            }
        } catch (e) {}

        value = encodeURIComponent(String(value))
            .replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);

        key = encodeURIComponent(String(key));
        key = key.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent);
        key = key.replace(/[\(\)]/g, escape);

        var stringifiedAttributes = '';

        for (var attributeName in attributes) {
            if (!attributes[attributeName]) {
                continue;
            }
            stringifiedAttributes += '; ' + attributeName;
            if (attributes[attributeName] === true) {
                continue;
            }
            stringifiedAttributes += '=' + attributes[attributeName];
        }
        return (document.cookie = key + '=' + value + stringifiedAttributes);
    }

    function get_is_in_iframe() {
        var is_in_iframe;
        try {
            is_in_iframe = window.self !== window.top;
        } catch (e) {
            is_in_iframe = true;
        }
        return is_in_iframe;
    }
    function get_screen_params() {
        var ratio = 1;
        if (window.screen.systemXDPI !== undefined && window.screen.logicalXDPI !== undefined && window.screen.systemXDPI > window.screen.logicalXDPI) {
            ratio = window.screen.systemXDPI / window.screen.logicalXDPI;
        } else if (window.devicePixelRatio !== undefined) {
            ratio = window.devicePixelRatio;
        }

        return {
            width: screen.width,
            height: screen.height,
            color_depth: screen.colorDepth,
            pixel_ratio: ratio,
        };
    }
    function get_timezone() {
        return Intl.DateTimeFormat().resolvedOptions().timeZone;
    }

    function ajax(url, method, data, callback) {
        var xhttp = new XMLHttpRequest();
        xhttp.withCredentials = true;
        xhttp.onreadystatechange = function() {
            if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                callback(this);
            }
        };
        xhttp.open(method, url, true);
        xhttp.setRequestHeader('Content-Type', 'text/plain');
        xhttp.send(JSON.stringify(data));
    }
    function ajax_post(url, data, callback = function () {}) {
        ajax(url, 'POST', data, callback);
    }

    function update_hit_cookie(hit, cookie_key) {
        var cc = 0;
        var interval = setInterval(function() {
            var cookie_val = get_cookie(cookie_key);
            if (cookie_val) {
                clearInterval(interval);
                var data = {
                    hit: hit,
                    cookies: {}
                };
                data.cookies[cookie_key] = cookie_val;
                ajax_post(prepareUrl(SETH_HIT_UPDATE_URL), data);
            }
            if (cc > 150) {
                clearInterval(interval);
            }
            cc++;
        }, 200);
    }

    function hit_collect(params) {
        var newCollectedHref = document.location.href.replace(document.location.hash, '');
        if (lastCollectedHref === newCollectedHref) {
            return;
        } else {
            lastCollectedHref = newCollectedHref;
        }

        var ga = get_cookie(SETH_COOKIE_NAME_GOOGLE);
        var ym = get_cookie(SETH_COOKIE_NAME_YANDEX);
        var guest = get_cookie(SETH_COOKIE_NAME_SKYENG_OLD);
        var user_id = (typeof params === "object") && (params !== null) && params.hasOwnProperty("userId")
            ? params.userId
            : null;
        ajax_post(
            prepareUrl(SETH_HIT_COLLECT_URL),
            {
                uri: window.location.href,
                referer: window.document.referrer,
                cookies: get_cookie(),
                user_agent: navigator.userAgent,
                is_in_iframe: get_is_in_iframe(),
                screen: get_screen_params(),
                timezone: get_timezone(),
                user_id: user_id
            },
            function (request) {
                var data = JSON.parse(request.responseText);
                if (typeof data.seid === 'undefined') {
                    return;
                }

                currentHitId = data.hit

                var date = new Date();
                date.setFullYear(date.getFullYear() + 1);
                set_cookie(SETH_COOKIE_NAME_SKYENG, data.seid, {
                    expires: date,
                    path: '/',
                    domain: get_cookie_domain(),
                    SameSite: 'None',
                    Secure: true
                });

                if (!get_cookie(SETH_COOKIE_NAME_SKYENG)) {
                    set_cookie(SETH_COOKIE_NAME_SKYENG, data.seid, {
                        expires: date,
                        path: '/',
                        domain: get_cookie_domain(),
                        Secure: true
                    });
                }

                if (!ga) {
                    update_hit_cookie(data.hit, SETH_COOKIE_NAME_GOOGLE);
                }
                if (!ym) {
                    update_hit_cookie(data.hit, SETH_COOKIE_NAME_YANDEX);
                }
                if (!guest) {
                    update_hit_cookie(data.hit, SETH_COOKIE_NAME_SKYENG_OLD);
                }

                notify_cookies_ready(data);
            }
        );
    }

    function notify_cookies_ready(data) {
        try {
          const { hit, seid } = data;
          const event = new CustomEvent("marketingHitCookiesReady", {
            detail: { seid, hit },
          });
          
          window.dispatchEvent(event);
        } catch (e) {}
    }

    function get_current_hit_id() {
        return currentHitId;
    }

    function set_timezone_to_cookie() {
        if (get_cookie(SETH_COOKIE_NAME_SKYENG_TIMEZONE) === get_timezone() ) {
            return;
        }
        var yearAgo = new Date();
        yearAgo.setFullYear(yearAgo.getFullYear() + 1);
        set_cookie(SETH_COOKIE_NAME_SKYENG_TIMEZONE, get_timezone(), {
            expires: yearAgo,
            path: '/',
            domain: get_cookie_domain(),
            SameSite: 'None',
            Secure: true
        });
    }

    function get_cookie_domain() {
        var domainParts = location.hostname.split('.').reverse();
        return '.' + domainParts[1] + '.' + domainParts[0];
    }

    if (!window.hasOwnProperty('skyengTrackHits')) {
        hit_collect();
        set_timezone_to_cookie();
        window.skyengTrackHits = {
            hit_collect: hit_collect,
            get_current_hit_id: get_current_hit_id
        };

        var oldPushState = window.history.pushState;

        window.history.pushState = function () {
            oldPushState.apply(window.history, arguments);
            setTimeout(function () {
                hit_collect();
            });
        };
    }
})(window);
