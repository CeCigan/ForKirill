<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\NeobychnyjPost;



class MainController extends Controller
{
    public function getMainPage(){
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=> 'Страница находится в стадии разработки', 
            'title'=> 'Главная',
            'posts' => '',
            'img' => '',
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    }

    public function getVelikieMuzei(){
        $velikieMuzei = Post::where('name', 'velikie-muzei')->first();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$velikieMuzei->content, 
            'title'=>$velikieMuzei->title,
            'posts' => $otherMuzei,
            'postPath' => 'velikie-muzei',
            'img' => '',
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    }

    public function getSubMuzei($submuzei){
        $muzei = Post::where('name', $submuzei)->first();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$muzei->content, 
            'title'=>$muzei->title,
            'posts' => '',
            'postPath' => '',
            'img' => $muzei->img,
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    } 

    public function getNews(){
        $novosti = Post::where('name','novosti')->first();
        $otherNovosti = Post::where('parent', 3)->get();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$novosti->content, 
            'title'=>$novosti->title,
            'posts' => $otherNovosti,
            'postPath' => 'novosti',
            'img' => '',
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    }

    public function getGalery(){
        $zhivopis = Post::where('name','zhivopis')->first();
        $otherZhivopis = Post::where('parent',4)->get();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$zhivopis->content, 
            'title'=>$zhivopis->title,
            'img' => '',
            'posts' => $otherZhivopis,
            'postPath' => 'zhivopis',
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
            
        ]);
    }

    public function getSubGalery($subzhivopis){
        $zhivopis = Post::where('name', $subzhivopis)->first();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$zhivopis->content, 
            'title'=>$zhivopis->title,
            'img' => $zhivopis->img,
            'posts' => '',
            'postPath' => '',
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    } 

    public function getSculptures(){
        $skulptura = Post::where('name','skulptura')->first();
        $otherSkulptura = Post::where('parent',9)->get();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$skulptura->content, 
            'title'=>$skulptura->title,
            'posts' => $otherSkulptura,
            'postPath' => 'skulptura',
            'img' => '',
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    }

    public function getSubSculptures($subskulptura){
        $skulptura = Post::where('name', $subskulptura)->first();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$skulptura->content, 
            'title'=>$skulptura->title,
            'posts' => '',
            'postPath' => '',
            'img' => $skulptura->img,
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    } 

    public function getCityes(){
        $goroda = Post::where('name','goroda')->first();
        $otherGoroda = Post::where('parent',10)->get();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$goroda->content, 
            'title'=>$goroda->title,
            'posts' => $otherGoroda,
            'postPath' => 'goroda',
            'img' => '',
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    }
    
    public function getSubCityes($subgorod){
        $goroda = Post::where('name', $subgorod)->first();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$goroda->content, 
            'title'=>$goroda->title,
            'posts' => '',
            'postPath' => '',
            'img' => $goroda->img,
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    }

    public function getNMM(){
        $nmm = NeobychnyjPost::where('name','neobychnye-muzei-mira')->first();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$nmm->content, 
            'title'=>$nmm->title,
            'posts' => $otherNmm,
            'postPath' => 'neobychnye-muzei-mira',
            'img' => '',
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    }

    public function getSubNMM($subnmm){
        $nmm = NeobychnyjPost::where('name', $subnmm)->first();
        //
        $otherMuzei = Post::where('parent',2)->get();
        $otherZhivopis = Post::where('parent',4)->get();
        $otherSkulptura = Post::where('parent',9)->get();
        $otherGoroda = Post::where('parent',10)->get();
        $otherNmm = NeobychnyjPost::where('parent',1)->get();
        return view('app',[
            'content'=>$nmm->content, 
            'title'=>$nmm->title,
            'posts' => '',
            'postPath' => '',
            'img' => $nmm->img,
            'otherMuzei' => $otherMuzei,
            'otherZhivopis' => $otherZhivopis,
            'otherSkulptura' => $otherSkulptura,
            'otherGoroda' => $otherGoroda,
            'otherNmm' => $otherNmm
        ]);
    }
}
