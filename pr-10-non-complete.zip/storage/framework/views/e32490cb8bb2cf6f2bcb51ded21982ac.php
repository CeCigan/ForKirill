<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>"> -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>">
</head>
<body>
    <header>
        <img src="<?php echo e(asset('/images/header-bckgr.jpg')); ?>" alt="header">
        <div class="header__text">
            <div class="header__title">Музеи Мира</div>
            <div class="header__subtitle">Виртуальная экскурсия</div>
        </div>
    </header>
    <nav>
        <a href="/" class="nav__item">Главная</a>
        <a href="/velikie-muzei/" class="nav__item">Великие музеи</a>
        <a href="/novosti" class="nav__item">Новости</a>
        <a href="/zhivopis" class="nav__item">Живопись</a>
        <a href="/skulptura" class="nav__item">Скульптура</a>
        <a href="/goroda" class="nav__item">Города</a>
        <a href="/neobychnye-muzei-mira" class="nav__item">Необычные музеи</a>
        <a href="/console" class="nav__item">Консоль</a>
    </nav>
    <main>
        <div class="wrapper">
            <h4 class="main__title">Великие музеи</h4>
            {<?php echo $velikieMuzei; ?>}
        </div>
    </main>
    <footer>
        <div class="footer__info">Музеи Мира</div>
    </footer>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\muzei-mira\resources\views/nav/velikie-muzei.blade.php ENDPATH**/ ?>