<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>"> -->
</head>
<body>
<header>
        <!-- <img src="<?php echo e(asset('/images/header-bckgr.jpg')); ?>" alt="header"> -->
        <div>
            <h1>
                Музеи Мира
            </h1>    
        </div>
        <div>
            <h2>Виртуальная экскурсия</h2>
        </div>
    </header>
    <nav>
        <ul class="menu">
            <li>
                <a href="/" class="nav__item">Главная</a>
            </li>
            <li>
                <a href="/velikie-muzei/" class="nav__item">Великие музеи</a>
            </li>
            <li>
                <a href="/novosti" class="nav__item">Новости</a>
            </li>
            <li>
                <a href="/zhivopis" class="nav__item">Живопись</a>
            </li>
            <li>
                <a href="/skulptura" class="nav__item">Скульптура</a>
            </li>
            <li>
                <a href="/goroda" class="nav__item">Города</a>
            </li>
            <li>
                <a href="/neobychnye-muzei-mira" class="nav__item">Необычные музеи</a>
            </li>
            <li>
                <a href="/console" class="nav__item">Консоль</a>
            </li>
            <li>
                <a href="/cart">Корзина</a>
            </li>
            <li>
                <a href="/logout">Выйти</a>
            </li>
        </ul>
    </nav>
    <main>
        <div class="wrapper">
            <h1>Корзина</h2>
            <?php
                $acc = 0;
            ?>
            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style='border:1px solid black;'> 
                <h2>Заказ</h2> 
                <p>Название: <?php echo e($trip->name); ?></p>
                <p>Стоимость: <?php echo e($trip->cost); ?> рублей</p>
                <a href="/cart/delete/<?php echo e($trip->id); ?>">Удалить</a>
            </div>
            <?php
                $acc += $trip->cost;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <h2>
                Общая стоимость: <?php echo e($acc); ?> рублей
            </h2>
        </div>
    </main>
    <footer>
        <div class="footer__info">Музеи Мира</div>
    </footer>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\muzei-mira\resources\views/cart.blade.php ENDPATH**/ ?>