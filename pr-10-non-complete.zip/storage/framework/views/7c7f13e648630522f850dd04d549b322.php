<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>muzei-mira</title>
    <link href="<?php echo e(asset('/css/app.css')); ?>">
    <link href="<?php echo e(asset('/css/style.css')); ?>">
    <link href="<?php echo e(asset('/css/main.css')); ?>">
</head>
<body>
    <header>
        <img src="<?php echo e(asset('/images/header-bckgr.jpg')); ?>" alt="header">
        <div class="header__title">Музеи Мира</div>
        <div class="header__subtitle">Виртуальная экскурсия</div>
    </header>
    <nav>
        <a href="/" class="nav__item">Главная</a>
        <a href="/" class="nav__item">Великие музеи</a>
        <a href="/zhivopis" class="nav__item">Новости</a>
        <a href="/" class="nav__item">Живопись</a>
        <a href="/" class="nav__item">Скульптура</a>
        <a href="/" class="nav__item">Города</a>
        <a href="/" class="nav__item">Необычные музеи</a>
        <a href="/" class="nav__item">Консоль</a>
    </nav>
    <main>
        {<?php echo $zhivopis; ?>}
    </main>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\muzei-mira\resources\views/nav/zhivopis.blade.php ENDPATH**/ ?>